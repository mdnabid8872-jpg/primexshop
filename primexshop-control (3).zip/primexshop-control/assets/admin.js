document.addEventListener('click',function(e){
  var add=e.target.closest('[data-add]');
  if(add){e.preventDefault();var t=document.getElementById(add.dataset.add),box=document.getElementById(add.dataset.into);
    var h=t.innerHTML.replace(/__i__/g,'n'+Date.now());box.insertAdjacentHTML('beforeend',h);return}
  var rm=e.target.closest('[data-remove]');
  if(rm){e.preventDefault();if(confirm('মুছে ফেলবেন?'))rm.closest('.pxs-row').remove()}
});
