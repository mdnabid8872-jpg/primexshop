(function(){
var C=window.PXS||{},$=function(id){return document.getElementById(id)};
if(!$('grid'))return;
var sel=null,pay=(C.pays&&C.pays[0])?C.pays[0]:null;
var esc=function(s){var d=document.createElement('div');d.textContent=s==null?'':s;return d.innerHTML};
var bn=function(n){return String(n).replace(/\d/g,function(d){return '০১২৩৪৫৬৭৮৯'[d]})};
var cur=C.cur||'৳';

$('grid').innerHTML=(C.tiles||[]).map(function(t){return '<div class="tile" data-t="'+esc(t[1])+'"><div class="img">'+esc(t[0])+'</div><div>'+esc(t[1])+'</div></div>'}).join('');
$('grid').onclick=function(e){var t=e.target.closest('.tile');if(t)openM(t.dataset.t)};
$('pk').innerHTML=(C.packs||[]).map(function(p,i){return '<div class="opt" data-i="'+i+'">'+esc(p.name)+'<small>'+cur+bn(p.price)+'</small></div>'}).join('');
$('pay').innerHTML=(C.pays||[]).map(function(p,i){return '<div class="opt'+(i===0?' sel':'')+'" data-p="'+i+'">'+esc(p.label)+'</div>'}).join('');

function showInfo(){
  var box=$('payinfo');if(!pay){box.textContent='';return}
  var t=pay.instructions||'';
  if(pay.mode!=='gateway'&&pay.number)t=(pay.payee?pay.payee+' — ':'')+pay.number+(t?'\n'+t:'');
  box.textContent=t;
  $('txnwrap').style.display=pay.mode==='gateway'?'none':'block';
}
$('pk').onclick=function(e){var o=e.target.closest('.opt');if(!o)return;sel=C.packs[o.dataset.i];
  Array.prototype.forEach.call($('pk').children,function(c){c.classList.toggle('sel',c===o)});$('tot').textContent=cur+bn(sel.price)};
$('pay').onclick=function(e){var o=e.target.closest('.opt');if(!o)return;pay=C.pays[o.dataset.p];
  Array.prototype.forEach.call($('pay').children,function(c){c.classList.toggle('sel',c===o)});showInfo()};
showInfo();

var WH=[["৳30","#e8803a"],["৳2","#f3b94f"],["৳100","#7b44e0"],["৳5","#e8667a"],["৳10","#4a7ff0"],["৳20","#dc78b0"],["৳1","#58b8a8"],["৳3","#9acd48"]];
$('wh').style.background='conic-gradient('+WH.map(function(w,i){return w[1]+' '+i*45+'deg '+(i+1)*45+'deg'}).join(',')+')';
WH.forEach(function(w,i){var a=i*45+22.5,s=document.createElement('div');s.className='lb';s.textContent='💲\n'+w[0];
  s.style.transform='rotate('+a+'deg) translateY(-92px) rotate('+(-a)+'deg)';$('wh').appendChild(s)});

function openM(t){$('mt').textContent=t;$('msg').textContent='';$('m').classList.add('on')}
window.pxsCloseM=function(){$('m').classList.remove('on')};
window.pxsOrder=async function(){
  var msg=$('msg'),uid=$('uid').value.trim();
  if(!/^\d{6,12}$/.test(uid)){msg.style.color='#ffb0b0';return msg.textContent='⚠️ সঠিক UID দিন'}
  if(!sel){msg.style.color='#ffb0b0';return msg.textContent='⚠️ একটি প্যাকেজ বাছাই করুন'}
  if(!pay){msg.style.color='#ffb0b0';return msg.textContent='⚠️ কোনো পেমেন্ট মাধ্যম চালু নেই'}
  msg.style.color='#9aa3d6';msg.textContent='প্রসেস হচ্ছে...';
  try{
    var r=await fetch(C.rest+'order',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({uid:uid,pack:sel.code,method:pay.id,txn:$('txn').value.trim()})});
    var d=await r.json();
    if(!r.ok||d.error){msg.style.color='#ffb0b0';return msg.textContent='⚠️ '+(d.error||d.message||'ত্রুটি হয়েছে')}
    if(d.payment_url){location.href=d.payment_url;return}
    msg.style.color='#7dffb0';msg.textContent=d.message||'অর্ডার গ্রহণ করা হয়েছে';
    if(d.upi_url){var a=document.createElement('a');a.href=d.upi_url;a.textContent='UPI অ্যাপে পেমেন্ট করুন';msg.appendChild(document.createElement('br'));msg.appendChild(a)}
  }catch(e){msg.style.color='#ffb0b0';msg.textContent='⚠️ সার্ভারে সংযোগ হয়নি, আবার চেষ্টা করুন'}
};
if(/[?&]pxs_order=\d+/.test(location.search)){openM('অর্ডার স্ট্যাটাস');$('msg').style.color='#7dffb0';$('msg').textContent='আপনার অর্ডার পেয়েছি। পেমেন্ট ভেরিফাই হলেই ডায়মন্ড পাঠানো হবে।'}
})();
