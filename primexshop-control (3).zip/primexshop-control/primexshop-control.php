<?php
/**
 * Plugin Name: PrimeXshop Control
 * Description: PrimeXshop Free Fire top-up storefront with a full WordPress admin panel: packages, tiles, payment methods (manual / UPI link / UPI gateway API), reseller API and orders. Use the shortcode [primexshop].
 * Version: 1.0.0
 * Text Domain: primexshop
 */
if (!defined('ABSPATH')) exit;

final class PXS {
	const OPT = 'pxs_settings';
	const VER = '1.0.0';

	/* ---------- settings ---------- */
	static function defaults() {
		$p = function ($id, $label, $en = 'no', $mode = 'manual') {
			return ['id'=>$id,'label'=>$label,'enabled'=>$en,'mode'=>$mode,'number'=>'','payee'=>'','instructions'=>'',
				'create_url'=>'','http_method'=>'POST','headers'=>'','body'=>'','url_path'=>'','api_key'=>'','api_secret'=>'',
				'wh_token'=>'','wh_hmac_header'=>'','wh_hmac_secret'=>'','wh_order_path'=>'','wh_status_path'=>'','wh_status_ok'=>''];
		};
		return [
			'site_name'=>'PrimeXshop','currency'=>'৳','currency_code'=>'BDT',
			'color_pri'=>'#2f5bff','color_acc'=>'#ff4d2e',
			'banner_l1'=>'যেকোনো','banner_em'=>'সমস্যা','banner_h1'=>'সমাধান করুন','banner_p'=>'মাত্র ৩০ সেকেন্ডে ⏱️',
			'link_whatsapp'=>'','link_support'=>'','link_telegram'=>'',
			'spin_text'=>'A lucky spin wheel is live — log in to play!',
			'packs'=>[
				['code'=>'d25','name'=>'25 💎','price'=>22],['code'=>'d50','name'=>'50 💎','price'=>42],
				['code'=>'d115','name'=>'115 💎','price'=>82],['code'=>'d240','name'=>'240 💎','price'=>165],
				['code'=>'d610','name'=>'610 💎','price'=>410],['code'=>'d1240','name'=>'1240 💎','price'=>820],
			],
			'tiles'=>[['💎','UID TOPUP'],['📅','WEEKLY'],['🗓️','MONTHLY'],['📦','WEEKLY + Monthly'],['🎫','Weekly Lite'],['⬆️','Level Up Packages'],['🇮🇩','Indonesia Topup'],['👍','Free Fire - 100 Like প্রতিদিন']],
			'pays'=>[$p('bkash','bKash','yes'),$p('nagad','Nagad','yes'),$p('rocket','Rocket','yes'),$p('upi','UPI','no','upi_link')],
			'reseller'=>['enabled'=>'no','url'=>'','headers'=>'','body'=>'','ok_path'=>'','ok_value'=>'','api_key'=>''],
		];
	}
	static function get($k = null) {
		$s = wp_parse_args(get_option(self::OPT, []), self::defaults());
		return $k === null ? $s : ($s[$k] ?? null);
	}
	static function table() { global $wpdb; return $wpdb->prefix . 'pxs_orders'; }

	static function install() {
		global $wpdb; require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate(); $t = self::table();
		dbDelta("CREATE TABLE $t (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created datetime NOT NULL,
			uid varchar(20) NOT NULL,
			pack_code varchar(60) NOT NULL,
			pack_name varchar(120) NOT NULL,
			amount decimal(12,2) NOT NULL,
			method varchar(60) NOT NULL,
			txn varchar(120) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'pending',
			gateway_ref varchar(190) NOT NULL DEFAULT '',
			log text,
			PRIMARY KEY  (id), KEY status (status)
		) $c;");
	}

	/* ---------- helpers ---------- */
	static function path($data, $path) {
		if (!is_array($data) || $path === '' || $path === null) return null;
		foreach (explode('.', $path) as $k) {
			if (is_array($data) && array_key_exists($k, $data)) $data = $data[$k]; else return null;
		}
		return $data;
	}
	static function tpl($str, $vars, $json = false) {
		$map = [];
		foreach ($vars as $k => $v) $map['{' . $k . '}'] = $json ? trim(wp_json_encode((string)$v), '"') : (string)$v;
		return strtr((string)$str, $map);
	}
	static function headers($text, $vars, $body) {
		$h = [];
		foreach (preg_split('/\r?\n/', (string)$text) as $line) {
			if (strpos($line, ':') === false) continue;
			list($n, $v) = array_map('trim', explode(':', self::tpl($line, $vars), 2));
			if ($n !== '') $h[$n] = $v;
		}
		$low = array_change_key_case($h);
		if (!isset($low['content-type']) && $body !== '')
			$h['Content-Type'] = in_array(substr(ltrim($body), 0, 1), ['{', '['], true) ? 'application/json' : 'application/x-www-form-urlencoded';
		return $h;
	}
	static function find($list, $key, $val) { foreach ((array)$list as $r) if (($r[$key] ?? null) === $val) return $r; return null; }
	static function log($id, $line) {
		global $wpdb; $t = self::table();
		$wpdb->query($wpdb->prepare("UPDATE $t SET log = CONCAT(IFNULL(log,''), %s) WHERE id = %d", gmdate('[Y-m-d H:i] ') . $line . "\n", $id));
	}
	static function set_status($id, $s) { global $wpdb; $wpdb->update(self::table(), ['status' => $s], ['id' => $id]); }
	static function order($id) { global $wpdb; $t = self::table(); return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d", $id)); }

	/* ---------- frontend ---------- */
	static function shortcode() {
		$s = self::get(); $u = plugin_dir_url(__FILE__);
		wp_enqueue_style('pxs-store', $u . 'assets/store.css', [], self::VER);
		wp_add_inline_style('pxs-store', '.pxs{--pri:' . sanitize_hex_color($s['color_pri']) . ';--acc:' . sanitize_hex_color($s['color_acc']) . '}');
		wp_enqueue_script('pxs-store', $u . 'assets/store.js', [], self::VER, true);
		$pays = [];
		foreach ($s['pays'] as $p) if ($p['enabled'] === 'yes')
			$pays[] = ['id'=>$p['id'],'label'=>$p['label'],'mode'=>$p['mode'],'number'=>$p['number'],'payee'=>$p['payee'],'instructions'=>$p['instructions']];
		wp_localize_script('pxs-store', 'PXS', [
			'rest'=>esc_url_raw(rest_url('primexshop/v1/')), 'cur'=>$s['currency'], 'pays'=>$pays,
			'packs'=>array_map(function ($p) { return ['code'=>$p['code'],'name'=>$p['name'],'price'=>$p['price']]; }, $s['packs']),
			'tiles'=>$s['tiles'],
		]);
		$link = function ($url, $bg, $ico, $small, $name) {
			return '<a href="' . esc_url($url ?: '#') . '" target="_blank" rel="noopener"><i style="background:' . $bg . '">' . $ico . '</i><span><small>' . $small . '</small>' . $name . '</span></a>';
		};
		ob_start(); ?>
<div class="pxs"><div class="wrap">
<header><div class="logo"><?php echo esc_html($s['site_name']); ?></div><div class="hr"><span>🔍</span><span>🛒</span>
<a class="btn" style="text-decoration:none" href="<?php echo esc_url(is_user_logged_in() ? admin_url('profile.php') : wp_login_url(get_permalink())); ?>">➜ <?php echo is_user_logged_in() ? 'Account' : 'Login'; ?></a></div></header>
<div class="banner"><div><h2><?php echo esc_html($s['banner_l1']); ?> <em><?php echo esc_html($s['banner_em']); ?></em></h2><h1><?php echo esc_html($s['banner_h1']); ?></h1><p><?php echo esc_html($s['banner_p']); ?></p></div><div class="hero">🎮</div></div>
<div class="links"><?php
	echo $link($s['link_whatsapp'], '#25d366', '💬', 'CHAT', 'WhatsApp');
	echo $link($s['link_support'], '#2f8bff', '🎧', 'HELP', 'Support');
	echo $link($s['link_telegram'], '#2aa3e6', '✈️', 'JOIN', 'Telegram'); ?></div>
<div class="spinbar" onclick="document.getElementById('sp').classList.add('on')"><i>🎲</i><div><small>LUCKY SPIN WHEEL</small><?php echo esc_html($s['spin_text']); ?></div><b>➜</b></div>
<h3>FREE FIRE</h3><div class="grid" id="grid"></div>
</div>
<div class="modal" id="sp" style="align-items:center"><div class="spin"><button class="x" onclick="document.getElementById('sp').classList.remove('on')">✕</button><div class="chip">🎲 SPIN &amp; WIN</div><h4>লাকি স্পিন</h4><div class="wheel" id="wh"><div class="hub">🎲</div></div><button class="btn spbtn" onclick="alert('স্পিন করতে আগে লগইন করুন')">🎲 LOG IN TO SPIN</button><div class="note">Please log in first to spin.</div></div></div>
<div class="modal" id="m"><div class="sheet">
<h4 id="mt">UID Top Up</h4>
<label>Free Fire UID</label><input id="uid" inputmode="numeric" placeholder="যেমন: 123456789">
<label>প্যাকেজ</label><div class="pk" id="pk"></div>
<label>পেমেন্ট মাধ্যম</label><div class="pay" id="pay"></div>
<div class="payinfo" id="payinfo"></div>
<div id="txnwrap" style="display:none"><label>ট্রানজেকশন ID / UTR</label><input id="txn" placeholder="পেমেন্টের পর পাওয়া ID"></div>
<div class="total"><span>মোট</span><span id="tot"><?php echo esc_html($s['currency']); ?>0</span></div>
<button class="btn" style="width:100%;padding:14px" onclick="pxsOrder()">অর্ডার করুন</button>
<div class="msg" id="msg"></div>
<button class="btn" style="width:100%;margin-top:10px;background:#232a5c" onclick="pxsCloseM()">বন্ধ করুন</button>
</div></div></div>
<?php
		return ob_get_clean();
	}

	/* ---------- REST: create order ---------- */
	static function err($m, $c = 400) { return new WP_REST_Response(['error' => $m], $c); }

	static function rest_order(WP_REST_Request $r) {
		global $wpdb;
		$k = 'pxs_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? ''); $n = (int)get_transient($k);
		if ($n >= 10) return self::err('অনেক বেশি চেষ্টা হয়েছে, কিছুক্ষণ পরে আবার চেষ্টা করুন', 429);
		set_transient($k, $n + 1, MINUTE_IN_SECONDS);

		$s = self::get();
		$uid = preg_replace('/\D/', '', (string)$r['uid']);
		if (!preg_match('/^\d{6,12}$/', $uid)) return self::err('সঠিক UID দিন');
		$pack = self::find($s['packs'], 'code', sanitize_text_field((string)$r['pack']));
		if (!$pack) return self::err('প্যাকেজ পাওয়া যায়নি');
		$pay = self::find($s['pays'], 'id', sanitize_key((string)$r['method']));
		if (!$pay || $pay['enabled'] !== 'yes') return self::err('এই পেমেন্ট মাধ্যম বন্ধ আছে');
		$txn = sanitize_text_field((string)$r['txn']);
		if ($pay['mode'] !== 'gateway' && strlen($txn) < 6) return self::err('ট্রানজেকশন ID / UTR দিন');

		$wpdb->insert(self::table(), [
			'created'=>current_time('mysql', true),'uid'=>$uid,'pack_code'=>$pack['code'],'pack_name'=>$pack['name'],
			'amount'=>(float)$pack['price'],'method'=>$pay['id'],'txn'=>$pay['mode'] === 'gateway' ? '' : $txn,'status'=>'pending',
		]);
		$id = (int)$wpdb->insert_id;
		if (!$id) return self::err('অর্ডার সেভ হয়নি', 500);

		if ($pay['mode'] === 'manual')
			return ['order_id'=>$id,'message'=>"অর্ডার #$id গ্রহণ করা হয়েছে। পেমেন্ট যাচাই হলেই ডায়মন্ড পাঠানো হবে।"];

		if ($pay['mode'] === 'upi_link') {
			$q = http_build_query(['pa'=>$pay['number'],'pn'=>$pay['payee'] ?: $s['site_name'],'am'=>number_format((float)$pack['price'], 2, '.', ''),'cu'=>$s['currency_code'] ?: 'INR','tn'=>'PXS' . $id], '', '&', PHP_QUERY_RFC3986);
			return ['order_id'=>$id,'upi_url'=>'upi://pay?' . $q,'message'=>"অর্ডার #$id গ্রহণ করা হয়েছে। পেমেন্ট করার পর যাচাই হলে ডায়মন্ড পাঠানো হবে।"];
		}

		// gateway (UPI API etc.)
		$vars = ['amount'=>$pack['price'],'order_id'=>$id,'uid'=>$uid,'pack'=>$pack['name'],'currency'=>$s['currency_code'],
			'redirect_url'=>add_query_arg('pxs_order', $id, home_url('/')),
			'webhook_url'=>add_query_arg('token', $pay['wh_token'], rest_url('primexshop/v1/webhook/' . $pay['id'])),
			'api_key'=>$pay['api_key'],'api_secret'=>$pay['api_secret'],'site_name'=>$s['site_name']];
		$body = self::tpl($pay['body'], $vars, true);
		$resp = wp_remote_request(self::tpl($pay['create_url'], $vars), [
			'method'=>$pay['http_method'] === 'GET' ? 'GET' : 'POST','timeout'=>20,
			'headers'=>self::headers($pay['headers'], $vars, $body),'body'=>$pay['http_method'] === 'GET' ? null : $body,
		]);
		if (is_wp_error($resp)) {
			self::set_status($id, 'failed'); self::log($id, 'gateway error: ' . $resp->get_error_message());
			return self::err('পেমেন্ট গেটওয়ে চালু করা যায়নি, আবার চেষ্টা করুন', 502);
		}
		$raw = wp_remote_retrieve_body($resp); $data = json_decode($raw, true);
		$url = self::path($data, $pay['url_path']);
		$ref = self::path($data, 'data.order_id') ?: self::path($data, 'order_id') ?: self::path($data, 'id');
		if (!is_string($url) || !preg_match('#^https?://#i', $url)) {
			self::set_status($id, 'failed'); self::log($id, 'no payment url. HTTP ' . wp_remote_retrieve_response_code($resp) . ' ' . mb_substr($raw, 0, 500));
			return self::err('পেমেন্ট লিংক পাওয়া যায়নি, সাপোর্টে যোগাযোগ করুন', 502);
		}
		if (is_scalar($ref)) $wpdb->update(self::table(), ['gateway_ref' => (string)$ref], ['id' => $id]);
		return ['order_id'=>$id,'payment_url'=>$url];
	}

	/* ---------- REST: gateway webhook ---------- */
	static function rest_webhook(WP_REST_Request $r) {
		$pay = self::find(self::get('pays'), 'id', sanitize_key($r['id']));
		if (!$pay || $pay['mode'] !== 'gateway' || $pay['wh_token'] === '') return self::err('forbidden', 403);
		if (!hash_equals($pay['wh_token'], (string)$r->get_param('token'))) return self::err('forbidden', 403);
		if ($pay['wh_hmac_secret'] !== '' && $pay['wh_hmac_header'] !== '') {
			$exp = hash_hmac('sha256', $r->get_body(), $pay['wh_hmac_secret']);
			if (!hash_equals($exp, strtolower(trim((string)$r->get_header($pay['wh_hmac_header']))))) return self::err('bad signature', 401);
		}
		$data = $r->get_json_params() ?: $r->get_params();
		$oid = (int)preg_replace('/\D/', '', (string)self::path($data, $pay['wh_order_path']));
		$st = strtolower((string)self::path($data, $pay['wh_status_path']));
		$ok = array_filter(array_map(function ($x) { return strtolower(trim($x)); }, explode(',', $pay['wh_status_ok'])));
		$o = $oid ? self::order($oid) : null;
		if (!$o || $o->method !== $pay['id']) return self::err('order not found', 404);
		if (in_array($st, $ok, true) && $o->status === 'pending') {
			self::log($oid, 'webhook: paid'); self::set_status($oid, 'paid'); self::deliver($oid);
		}
		return ['ok' => true];
	}

	/* ---------- reseller delivery ---------- */
	static function deliver($id) {
		$o = self::order($id); $rs = self::get('reseller');
		if (!$o) return;
		if ($rs['enabled'] !== 'yes' || $rs['url'] === '') { self::log($id, 'paid — manual delivery needed'); return; }
		$vars = ['uid'=>$o->uid,'pack_code'=>$o->pack_code,'order_id'=>$id,'api_key'=>$rs['api_key'],'amount'=>$o->amount];
		$body = self::tpl($rs['body'], $vars, true);
		$resp = wp_remote_post(self::tpl($rs['url'], $vars), ['timeout'=>25,'headers'=>self::headers($rs['headers'], $vars, $body),'body'=>$body]);
		if (is_wp_error($resp)) { self::log($id, 'reseller error: ' . $resp->get_error_message()); return; }
		$code = (int)wp_remote_retrieve_response_code($resp); $raw = wp_remote_retrieve_body($resp);
		$good = $code >= 200 && $code < 300;
		if ($good && $rs['ok_path'] !== '') $good = strtolower((string)self::path(json_decode($raw, true), $rs['ok_path'])) === strtolower($rs['ok_value']);
		self::log($id, 'reseller HTTP ' . $code . ' ' . mb_substr($raw, 0, 300));
		if ($good) self::set_status($id, 'delivered');
	}

	/* ---------- admin ---------- */
	static function menu() {
		add_menu_page('PrimeXshop', 'PrimeXshop', 'manage_options', 'primexshop', [__CLASS__, 'page'], 'dashicons-cart', 58);
	}
	static function f($name, $label, $val, $type = 'text', $hint = '') {
		echo '<p><label><strong>' . esc_html($label) . '</strong><br>';
		if ($type === 'textarea') echo '<textarea name="' . esc_attr($name) . '" rows="4" class="large-text code">' . esc_textarea($val) . '</textarea>';
		elseif ($type === 'secret') echo '<input type="password" autocomplete="new-password" name="' . esc_attr($name) . '" class="regular-text" value="" placeholder="' . ($val !== '' ? '•••••• সেভ করা আছে — বদলাতে নতুন মান লিখুন' : '') . '">';
		else echo '<input type="' . esc_attr($type) . '" name="' . esc_attr($name) . '" class="regular-text" value="' . esc_attr($val) . '">';
		echo '</label>' . ($hint ? '<br><span class="description">' . $hint . '</span>' : '') . '</p>';
	}
	static function sel($name, $label, $val, $opts) {
		echo '<p><label><strong>' . esc_html($label) . '</strong><br><select name="' . esc_attr($name) . '">';
		foreach ($opts as $k => $v) echo '<option value="' . esc_attr($k) . '"' . selected($val, $k, false) . '>' . esc_html($v) . '</option>';
		echo '</select></label></p>';
	}
	static function pay_row($i, $p) {
		$n = "pays[$i]"; $d = self::defaults()['pays'][0]; $p = wp_parse_args($p, $d);
		echo '<div class="pxs-row card"><button class="button-link-delete" style="float:right" data-remove>✕ মুছুন</button>';
		echo '<h3 style="margin-top:0">' . esc_html($p['label'] ?: 'নতুন পেমেন্ট মাধ্যম') . '</h3>';
		self::f($n . '[label]', 'নাম (সাইটে যা দেখাবে)', $p['label']);
		self::f($n . '[id]', 'ID (ইংরেজি ছোট হাতের, যেমন upi)', $p['id']);
		self::sel($n . '[enabled]', 'অবস্থা', $p['enabled'], ['yes'=>'চালু','no'=>'বন্ধ']);
		self::sel($n . '[mode]', 'ধরন', $p['mode'], ['manual'=>'ম্যানুয়াল (নম্বরে টাকা পাঠিয়ে TrxID দেবে)','upi_link'=>'UPI লিংক (UPI ID + UTR, অ্যাডমিন যাচাই করবে)','gateway'=>'গেটওয়ে API (অটো পেমেন্ট + ওয়েবহুক)']);
		self::f($n . '[number]', 'নম্বর / UPI ID', $p['number']);
		self::f($n . '[payee]', 'প্রাপকের নাম', $p['payee']);
		self::f($n . '[instructions]', 'ইউজারের জন্য নির্দেশনা', $p['instructions'], 'textarea');
		echo '<details><summary><strong>গেটওয়ে API সেটিংস (শুধু "গেটওয়ে API" ধরনের জন্য)</strong></summary>';
		echo '<p class="description">প্লেসহোল্ডার: {amount} {order_id} {uid} {pack} {currency} {redirect_url} {webhook_url} {api_key} {api_secret} {site_name}</p>';
		self::f($n . '[create_url]', 'অর্ডার তৈরির API URL', $p['create_url'], 'url');
		self::sel($n . '[http_method]', 'HTTP মেথড', $p['http_method'], ['POST'=>'POST','GET'=>'GET']);
		self::f($n . '[headers]', 'Headers (প্রতি লাইনে একটি: Name: value)', $p['headers'], 'textarea');
		self::f($n . '[body]', 'Body (JSON বা form টেমপ্লেট)', $p['body'], 'textarea');
		self::f($n . '[url_path]', 'রেসপন্সে পেমেন্ট লিংকের পাথ (যেমন data.payment_url)', $p['url_path']);
		self::f($n . '[api_key]', 'API Key', $p['api_key'], 'secret');
		self::f($n . '[api_secret]', 'API Secret', $p['api_secret'], 'secret');
		echo '<hr><h4>ওয়েবহুক (পেমেন্ট নিশ্চিত হওয়ার কলব্যাক)</h4>';
		if ($p['id']) echo '<p>গেটওয়ে ড্যাশবোর্ডে এই URL বসান:<br><code>' . esc_html(rest_url('primexshop/v1/webhook/' . $p['id'])) . '?token=আপনার_টোকেন</code></p>';
		self::f($n . '[wh_token]', 'ওয়েবহুক টোকেন (বাধ্যতামূলক — লম্বা র‍্যান্ডম লিখুন)', $p['wh_token'], 'secret');
		self::f($n . '[wh_hmac_header]', 'HMAC সিগনেচার হেডারের নাম (ঐচ্ছিক)', $p['wh_hmac_header']);
		self::f($n . '[wh_hmac_secret]', 'HMAC সিক্রেট (ঐচ্ছিক, SHA256)', $p['wh_hmac_secret'], 'secret');
		self::f($n . '[wh_order_path]', 'ওয়েবহুকে আমাদের অর্ডার ID-র পাথ', $p['wh_order_path']);
		self::f($n . '[wh_status_path]', 'ওয়েবহুকে স্ট্যাটাসের পাথ', $p['wh_status_path']);
		self::f($n . '[wh_status_ok]', 'সফল স্ট্যাটাস মান (কমা দিয়ে, যেমন success,paid)', $p['wh_status_ok']);
		echo '</details></div>';
	}

	static function page() {
		if (!current_user_can('manage_options')) return;
		$tab = sanitize_key($_GET['tab'] ?? 'general'); $s = self::get();
		$tabs = ['general'=>'সাধারণ','packs'=>'প্যাকেজ','tiles'=>'ক্যাটাগরি','pays'=>'পেমেন্ট মেথড','reseller'=>'রিসেলার API','orders'=>'অর্ডার'];
		echo '<div class="wrap"><h1>PrimeXshop কন্ট্রোল</h1>';
		if (isset($_GET['saved'])) echo '<div class="notice notice-success is-dismissible"><p>সেভ হয়েছে ✔</p></div>';
		echo '<nav class="nav-tab-wrapper">';
		foreach ($tabs as $k => $v) echo '<a class="nav-tab' . ($tab === $k ? ' nav-tab-active' : '') . '" href="' . esc_url(admin_url('admin.php?page=primexshop&tab=' . $k)) . '">' . esc_html($v) . '</a>';
		echo '</nav><style>.pxs-row.card{max-width:760px;padding:12px 18px;margin:12px 0}.pxs-line{display:flex;gap:8px;margin:6px 0}</style>';
		if ($tab === 'orders') { self::orders_tab(); echo '</div>'; return; }
		echo '<p>পেজে দেখাতে শর্টকোড: <code>[primexshop]</code> (সবচেয়ে ভালো দেখায় ফাঁকা/Canvas টেমপ্লেটের পেজে)</p>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field('pxs_save'); echo '<input type="hidden" name="action" value="pxs_save"><input type="hidden" name="tab" value="' . esc_attr($tab) . '">';

		if ($tab === 'general') {
			foreach (['site_name'=>'সাইটের নাম','currency'=>'মুদ্রার চিহ্ন (৳ / ₹)','currency_code'=>'মুদ্রা কোড (BDT / INR)','banner_l1'=>'ব্যানার: প্রথম অংশ','banner_em'=>'ব্যানার: লাল শব্দ','banner_h1'=>'ব্যানার: বড় লেখা','banner_p'=>'ব্যানার: নিচের লাইন','spin_text'=>'স্পিন বারের লেখা'] as $k => $l) self::f($k, $l, $s[$k]);
			self::f('color_pri', 'প্রাইমারি রং', $s['color_pri'], 'color'); self::f('color_acc', 'অ্যাকসেন্ট রং', $s['color_acc'], 'color');
			self::f('link_whatsapp', 'WhatsApp লিংক', $s['link_whatsapp'], 'url'); self::f('link_support', 'Support লিংক', $s['link_support'], 'url'); self::f('link_telegram', 'Telegram লিংক', $s['link_telegram'], 'url');
		} elseif ($tab === 'packs') {
			echo '<p class="description">কোড = রিসেলার API-র প্যাকেজ আইডি। দাম সার্ভারে যাচাই হয়, তাই ইউজার বদলাতে পারবে না।</p><div id="rows">';
			foreach ($s['packs'] as $i => $p) self::pack_row($i, $p);
			echo '</div><template id="tpl"></template>';
			echo '<script>document.getElementById("tpl").innerHTML=' . wp_json_encode(self::capture('pack_row', '__i__', ['code'=>'','name'=>'','price'=>''])) . ';</script>';
			echo '<p><button class="button" data-add="tpl" data-into="rows">+ প্যাকেজ যোগ করুন</button></p>';
		} elseif ($tab === 'tiles') {
			echo '<div id="rows">';
			foreach ($s['tiles'] as $i => $t) self::tile_row($i, $t);
			echo '</div><template id="tpl"></template><script>document.getElementById("tpl").innerHTML=' . wp_json_encode(self::capture('tile_row', '__i__', ['', ''])) . ';</script>';
			echo '<p><button class="button" data-add="tpl" data-into="rows">+ ক্যাটাগরি যোগ করুন</button></p>';
		} elseif ($tab === 'pays') {
			echo '<div id="rows">';
			foreach ($s['pays'] as $i => $p) self::pay_row($i, $p);
			echo '</div><template id="tpl"></template><script>document.getElementById("tpl").innerHTML=' . wp_json_encode(self::capture('pay_row', '__i__', ['enabled'=>'no','mode'=>'manual'])) . ';</script>';
			echo '<p><button class="button" data-add="tpl" data-into="rows">+ পেমেন্ট মাধ্যম যোগ করুন</button></p>';
		} elseif ($tab === 'reseller') {
			$r = $s['reseller'];
			echo '<p class="description">পেমেন্ট নিশ্চিত হলে এই API কল করে অটো ডায়মন্ড পাঠানো হবে। প্লেসহোল্ডার: {uid} {pack_code} {order_id} {api_key} {amount}</p>';
			self::sel('r[enabled]', 'অটো ডেলিভারি', $r['enabled'], ['no'=>'বন্ধ (ম্যানুয়াল)','yes'=>'চালু']);
			self::f('r[url]', 'রিসেলার API URL', $r['url'], 'url');
			self::f('r[headers]', 'Headers (Name: value)', $r['headers'], 'textarea');
			self::f('r[body]', 'Body টেমপ্লেট', $r['body'], 'textarea');
			self::f('r[api_key]', 'রিসেলার API Key', $r['api_key'], 'secret');
			self::f('r[ok_path]', 'সফলতার ফিল্ড পাথ (ঐচ্ছিক, যেমন status)', $r['ok_path']);
			self::f('r[ok_value]', 'সফলতার মান (যেমন success)', $r['ok_value']);
		}
		submit_button('সেভ করুন'); echo '</form></div>';
	}
	static function capture($fn, ...$a) { ob_start(); self::$fn(...$a); return ob_get_clean(); }
	static function pack_row($i, $p) {
		echo '<div class="pxs-row pxs-line"><input name="packs[' . esc_attr($i) . '][code]" placeholder="কোড" value="' . esc_attr($p['code']) . '">'
			. '<input name="packs[' . esc_attr($i) . '][name]" placeholder="নাম (25 💎)" value="' . esc_attr($p['name']) . '">'
			. '<input name="packs[' . esc_attr($i) . '][price]" type="number" step="0.01" placeholder="দাম" value="' . esc_attr($p['price']) . '">'
			. '<button class="button-link-delete" data-remove>✕</button></div>';
	}
	static function tile_row($i, $t) {
		echo '<div class="pxs-row pxs-line"><input name="tiles[' . esc_attr($i) . '][0]" size="4" placeholder="ইমোজি" value="' . esc_attr($t[0] ?? '') . '">'
			. '<input name="tiles[' . esc_attr($i) . '][1]" class="regular-text" placeholder="টাইটেল" value="' . esc_attr($t[1] ?? '') . '">'
			. '<button class="button-link-delete" data-remove>✕</button></div>';
	}

	static function save() {
		if (!current_user_can('manage_options')) wp_die('forbidden');
		check_admin_referer('pxs_save');
		$tab = sanitize_key($_POST['tab'] ?? ''); $in = wp_unslash($_POST); $s = self::get();
		$t = 'sanitize_text_field'; $ta = 'sanitize_textarea_field';
		if ($tab === 'general') {
			foreach (['site_name','currency','currency_code','banner_l1','banner_em','banner_h1','banner_p','spin_text'] as $k) $s[$k] = $t($in[$k] ?? '');
			foreach (['color_pri','color_acc'] as $k) $s[$k] = sanitize_hex_color($in[$k] ?? '') ?: $s[$k];
			foreach (['link_whatsapp','link_support','link_telegram'] as $k) $s[$k] = esc_url_raw($in[$k] ?? '');
		} elseif ($tab === 'packs') {
			$s['packs'] = [];
			foreach ((array)($in['packs'] ?? []) as $p) { $c = $t($p['code'] ?? ''); if ($c !== '') $s['packs'][] = ['code'=>$c,'name'=>$t($p['name'] ?? ''),'price'=>max(0, (float)($p['price'] ?? 0))]; }
		} elseif ($tab === 'tiles') {
			$s['tiles'] = [];
			foreach ((array)($in['tiles'] ?? []) as $x) { if (trim($x[1] ?? '') !== '') $s['tiles'][] = [$t($x[0] ?? ''), $t($x[1])]; }
		} elseif ($tab === 'pays') {
			$old = $s['pays']; $s['pays'] = []; $seen = [];
			foreach ((array)($in['pays'] ?? []) as $p) {
				$id = sanitize_key($p['id'] ?? '') ?: sanitize_key($p['label'] ?? '');
				if ($id === '' || isset($seen[$id])) continue; $seen[$id] = 1;
				$prev = self::find($old, 'id', $id) ?: [];
				$row = ['id'=>$id,'label'=>$t($p['label'] ?? ''),'enabled'=>($p['enabled'] ?? '') === 'yes' ? 'yes' : 'no',
					'mode'=>in_array($p['mode'] ?? '', ['manual','upi_link','gateway'], true) ? $p['mode'] : 'manual',
					'number'=>$t($p['number'] ?? ''),'payee'=>$t($p['payee'] ?? ''),'instructions'=>$ta($p['instructions'] ?? ''),
					'create_url'=>esc_url_raw($p['create_url'] ?? ''),'http_method'=>($p['http_method'] ?? '') === 'GET' ? 'GET' : 'POST',
					'headers'=>$ta($p['headers'] ?? ''),'body'=>$ta($p['body'] ?? ''),'url_path'=>$t($p['url_path'] ?? ''),
					'wh_hmac_header'=>$t($p['wh_hmac_header'] ?? ''),'wh_order_path'=>$t($p['wh_order_path'] ?? ''),
					'wh_status_path'=>$t($p['wh_status_path'] ?? ''),'wh_status_ok'=>$t($p['wh_status_ok'] ?? '')];
				foreach (['api_key','api_secret','wh_token','wh_hmac_secret'] as $k) {
					$v = $t($p[$k] ?? ''); $row[$k] = $v !== '' ? $v : ($prev[$k] ?? '');
				}
				$s['pays'][] = $row;
			}
		} elseif ($tab === 'reseller') {
			$r = (array)($in['r'] ?? []); $k = $t($r['api_key'] ?? '');
			$s['reseller'] = ['enabled'=>($r['enabled'] ?? '') === 'yes' ? 'yes' : 'no','url'=>esc_url_raw($r['url'] ?? ''),
				'headers'=>$ta($r['headers'] ?? ''),'body'=>$ta($r['body'] ?? ''),'ok_path'=>$t($r['ok_path'] ?? ''),'ok_value'=>$t($r['ok_value'] ?? ''),
				'api_key'=>$k !== '' ? $k : $s['reseller']['api_key']];
		}
		update_option(self::OPT, $s, false);
		wp_safe_redirect(admin_url('admin.php?page=primexshop&tab=' . $tab . '&saved=1')); exit;
	}

	static function orders_tab() {
		global $wpdb; $t = self::table(); $s = self::get();
		$rows = $wpdb->get_results("SELECT * FROM $t ORDER BY id DESC LIMIT 150");
		echo '<table class="widefat striped" style="margin-top:12px"><thead><tr><th>#</th><th>সময় (UTC)</th><th>UID</th><th>প্যাকেজ</th><th>টাকা</th><th>মাধ্যম</th><th>TrxID/UTR</th><th>স্ট্যাটাস</th><th>অ্যাকশন</th></tr></thead><tbody>';
		foreach ($rows as $o) {
			$mk = function ($do, $label) use ($o) {
				return '<a class="button button-small" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=pxs_order&do=' . $do . '&id=' . $o->id), 'pxs_order_' . $o->id)) . '">' . $label . '</a> ';
			};
			echo '<tr><td>' . (int)$o->id . '</td><td>' . esc_html($o->created) . '</td><td>' . esc_html($o->uid) . '</td><td>' . esc_html($o->pack_name) . '</td><td>' . esc_html($s['currency'] . $o->amount) . '</td><td>' . esc_html($o->method) . '</td><td>' . esc_html($o->txn) . '</td><td title="' . esc_attr($o->log) . '"><strong>' . esc_html($o->status) . '</strong></td><td>';
			if (in_array($o->status, ['pending', 'failed'], true)) echo $mk('paid', 'পেইড + ডেলিভার');
			if ($o->status === 'paid') echo $mk('deliver', 'আবার ডেলিভারি চেষ্টা') . $mk('delivered', 'ডেলিভার্ড চিহ্নিত');
			if ($o->status !== 'cancelled' && $o->status !== 'delivered') echo $mk('cancel', 'বাতিল');
			echo '</td></tr>';
		}
		if (!$rows) echo '<tr><td colspan="9">এখনো কোনো অর্ডার নেই</td></tr>';
		echo '</tbody></table><p class="description">স্ট্যাটাসের উপর মাউস রাখলে লগ দেখা যাবে।</p>';
	}
	static function order_action() {
		$id = (int)($_GET['id'] ?? 0);
		if (!current_user_can('manage_options')) wp_die('forbidden');
		check_admin_referer('pxs_order_' . $id);
		$do = sanitize_key($_GET['do'] ?? '');
		if ($do === 'paid') { self::set_status($id, 'paid'); self::log($id, 'admin: marked paid'); self::deliver($id); }
		elseif ($do === 'deliver') self::deliver($id);
		elseif ($do === 'delivered') { self::set_status($id, 'delivered'); self::log($id, 'admin: marked delivered'); }
		elseif ($do === 'cancel') { self::set_status($id, 'cancelled'); self::log($id, 'admin: cancelled'); }
		wp_safe_redirect(admin_url('admin.php?page=primexshop&tab=orders')); exit;
	}
	static function admin_assets($hook) {
		if ($hook === 'toplevel_page_primexshop') wp_enqueue_script('pxs-admin', plugin_dir_url(__FILE__) . 'assets/admin.js', [], self::VER, true);
	}
}

register_activation_hook(__FILE__, ['PXS', 'install']);
add_shortcode('primexshop', ['PXS', 'shortcode']);
add_action('admin_menu', ['PXS', 'menu']);
add_action('admin_enqueue_scripts', ['PXS', 'admin_assets']);
add_action('admin_post_pxs_save', ['PXS', 'save']);
add_action('admin_post_pxs_order', ['PXS', 'order_action']);
add_action('rest_api_init', function () {
	register_rest_route('primexshop/v1', '/order', ['methods'=>'POST','callback'=>['PXS','rest_order'],'permission_callback'=>'__return_true']);
	register_rest_route('primexshop/v1', '/webhook/(?P<id>[a-z0-9_-]+)', ['methods'=>['POST','GET'],'callback'=>['PXS','rest_webhook'],'permission_callback'=>'__return_true']);
});
